class Fracao{
     
    constructor(numerador, denominador){
       this.num = numerador;
       this.den = denominador;
    }

    multiplicacao(f){
        return (this.num * f.num) + "/" + (this.den * f.den)
    }

    divisao(f){
        return (this.num * f.den) + "/" + (this.den * f.num)
    }

}
 
export default Fracao;
