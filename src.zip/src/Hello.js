export default class Hello {
	sum(x, y) {
		return x + y;
	}
	sayHello() {
		return "hello"
	}
	mult(x, y) {
		return x*y;
	}
}