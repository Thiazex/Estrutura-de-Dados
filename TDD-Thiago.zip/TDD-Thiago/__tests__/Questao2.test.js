import Pilha from "../src/Questao2";

let pilha1

beforeEach(() => {
  pilha1 = new Pilha(5); 
});

test("questao 2", () => {
    pilha1.push(1);
    pilha1.push(2);
    pilha1.push(3);
    pilha1.push(4);
    pilha1.push(5);
    expect(pilha1.Inverte()).toBe("[52341]");
  });
  
