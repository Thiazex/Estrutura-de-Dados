import Fracao from "../src/Questao1";

let f1 , f2;

beforeEach(() => {
    f1 = new Fracao(1,2)
    f2 = new Fracao(2,3);    
});

test("Multiplicação", () => {
    expect(f1.multiplicacao(f2)).toBe("2/6");
});

test("Divisão", () => {
    expect(f1.divisao(f2)).toBe("3/4");
});
