import Pilha from "./Pilhas"

class Invercao{
    
    constructor(){
      this.pilha1 = new Pilha(5);
      this.pilha2 = new Pilha(5);
      this.pilhaAux = new Pilha(5);
    }


    push(num){
        this.pilha1.push(num);
    }

    Inverte(){
        this.pilha2.push(this.pilha1.pop());

        for(let i = 1; i!=this.pilha1.size(); ){
            this.pilhaAux.push(this.pilha1.pop());
        }

        for(let i = 1; i<=this.pilhaAux.size(); ){
            this.pilha2.push(this.pilhaAux.pop());
        }

        this.pilha2.push(this.pilha1.pop());

        return this.pilha2.toString();
    }
}

export default Invercao;